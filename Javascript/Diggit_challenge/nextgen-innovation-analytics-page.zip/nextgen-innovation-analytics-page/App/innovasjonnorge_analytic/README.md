# Design Doc
Author: Katrine Marie Jaskiewicz Grytten

This solution is made to take in data from API or other import and store it and handles changes in data display via dispatches which can be activated by attacment to their respective buttons. The store can be accessed from anywhere. The data is then passed to each component hosting a dynamic fragment in the app. Since I'm unsure what the chart menu items are to be used for I've left their functionalities blank for later development.
To use this layout, simply store the values to be displayed in the Redux store.

Note for further development: The displays have been made so they can easily switch contents. When developing the Account page and login system it might be a good idea to store the profile information sepatate from the data store.

Notable data requirements:
- meeting time should be formatted to a constant length of output string counting font-size
- ticklabels of GradientGraph should be reworked to an adaptable date system according to format of data

Remaining issues:
- Unable to change certain parts of graph to assimilte prototype due to gradient chart options bugs related to sizing, callback and tooltip. Try changing the values on "line" in GradientGraphs data function instead.
- fix lock svg bug
- remove indent borderline on chart menu
- solid select arrow
- make margins and paddings unscalable with px instead of vmin, In Progress
- alt text for images
- draw inner circle on GradientGraph tooltip 

Log:
- profile date formatted
- fixed layout of meeting list
- Fonts
- Polished Profile Fragment
- Added crosshairs hover effect on gradient chart
- Fixed bug activating custom crosshair plugin on doughnut
- Styled and resized every item to be closer to prototype
- Created dummy data and passed it to their respective fragments
- Established Redux store
- Fixed image filepath bug
- Filled in menus, and created components to host their fragment
- Implemented gradient and doughnut line chart with react-chartjs-2
- Made basic layout of each fragment
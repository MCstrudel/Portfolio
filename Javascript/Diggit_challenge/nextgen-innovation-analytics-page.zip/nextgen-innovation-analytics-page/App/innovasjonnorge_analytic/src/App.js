import React from 'react';
import './App.css';
import GradientGraph from './app/components/GradientGraph';
import DoughnutGraph from './app/components/DoughnutGraph';
import ChartMenu from './app/components/ChartMenu';
import IconMenu from './app/components/IconMenu';
import Banner from './app/components/Banner';
import LatestContent from './app/components/LatestContent';
import ParameterDisplay from './app/components/ParameterDisplay';
import Profile from './app/components/Profile';

import logo from './assets/images/logo.png';
import icMenu1 from "./assets/icons/Group174.svg";
import icMenu2 from "./assets/icons/funds.svg"; 
import icMenu3 from "./assets/icons/Path188.svg";
import icMenu4 from "./assets/icons/history.svg";
import icMenu5 from "./assets/icons/verification-window-button.svg";
import icMenu6 from "./assets/icons/locked-padlock1.svg";

import { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  signups, investments, revenue, exits, trades, selectData,
} from './features/redux_data/dataSlice';
import dataReducer from './features/redux_data/dataSlice';


function App() {
  const state = useSelector(selectData);
  const data = state.data;
  const overhead = state.overhead;
  const meetings = state.meetings;
  const parameter = state.parameters.gender;
  const profile = state.profile;

  return (
    <div className="App">
      <header >
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <menu className="Nav">
            <li>ACCOUNT</li>
            <li>CHARTS</li>
            <li>HELP</li>
          </menu>
          <div className="Profile">
            <Profile name={profile.name} imgsrc={profile.imgsrc} />
          </div>
        </div>

        <Banner overhead={overhead}/>

        <div className="App-body">
        <ChartMenu />

        <div className= "chart">
        <IconMenu content={[icMenu1,icMenu2,icMenu3,icMenu4,icMenu5,icMenu6]}/>
        
        <div className="display">
          <div className="charts">
            <div id="element">
              <GradientGraph 
              data={data.individuals[0]}
              labels={data.timestamps} 
              label="Individuals"
              color1={["rgba(78, 255, 207,1)"]}
              color2={"rgba(8, 164, 188,1)"}/>
            </div>
            <div id="element">
              <GradientGraph 
              data={data.companies[0]}
              labels={data.timestamps}
              label="Companies"
              color1={["rgba(255, 86, 238,1)"]}
              color2={"rgba(62, 87, 194,1)"}/>
            </div>
          </div>
          <div className="analytic">
            <div id="element">
              <DoughnutGraph 
              data={[
                data.individuals[0].reduce((a,b) => a+b)
              ,
                data.companies[0].reduce((a,b) => a+b)
              ]} 
              labels={["Individuals","Companies"]}/></div>

            <div id="element">
              <ParameterDisplay parameter={parameter.name} parameterOptions={parameter.options} />
            </div>

            <div id="element" className="latest" >
              
              <LatestContent meetings={meetings} />
              
            </div>
          </div>
          
        </div>
        </div>
      </div>
      </header>
      
    </div>
  );
}

export default App;

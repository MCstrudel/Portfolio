import React from 'react'
import {format} from 'date-fns'

export default class Profile extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            name: this.props.name,
            imgsrc: this.props.imgsrc,
            type: this.props.type, //whether user is an individual or a company
            time: new Date()
        }
    }
    render(){
        return(
         <div
         style={{display: "flex", flexDirection: "row"}}
         >
             <img 
             height="100%"
             src={this.state.imgsrc}
             style={{
                 position: "relative",
                 left: "-25px",
                 top: "20px"
             }}
             />
             <div className="profile"
             style={{justifyContent: "space-around"}}
             >
                <div width="200px" style={{float: "left", marginTop:"5%"}}>
                    <div>{this.state.name}</div></div>
                
                <div width="200px" style={{float: "right",marginLeft: "5vmin"}}>
                    
                    <p>{format(this.state.time,"dd-MM-yyyy")}</p>

                <p>{format(this.state.time,"hh.mma")}</p>
                </div>
                
             </div>  
         </div>
        )
    }
}
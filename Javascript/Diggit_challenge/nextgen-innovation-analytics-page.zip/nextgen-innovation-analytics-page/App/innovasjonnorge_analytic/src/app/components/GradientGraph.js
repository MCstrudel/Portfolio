import React from 'react'
import {Chart, Line} from 'react-chartjs-2'

export default class GradientGraph extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            data: {
                labels: this.props.labels,
                datasets: [{
                    label: this.props.label,
                    data: this.props.data
                }]
            },
            options: {
                title: {
                    display: true,
                    text: this.props.label,
                    fontColor: "white",
                    //unidentified issue editing font size
                },
                legend: {
                    display: false
                },
                scales: {
                    xAxes: [{
                        gridLines: {
                        display:false,
                        drawBorder: false,
                        drawTicks: false,
                        
                    },
                    ticks:{
                        fontColor:"white",
                    }
                    }],
                    yAxes: [
                        {
                            ticks: {
                                min: 0 ,
                                max: 12,
                                stepSize: 3
                            },
                            gridLines: {
                                display:false,
                                drawBorder: false,
                                drawTicks: false,
                        },
                        ticks:{
                            fontColor:"white"
                            //issue with padding option
                        }
                    }
                    ],
                    gridLines: {
                        display: false
                    }
                },
                tooltips: { //unidentified issue with editing the callbacks of the graph
                    backgroundColor: "transparent",
                    displayColor: "false",
                },
                
            }
        }
    }
   
    componentWillMount() { //draws crosshairs
        Chart.pluginService.register({
          afterDraw: function(chart, easing) {
            if (chart.scales['y-axis-0'] && chart.tooltip._active && chart.tooltip._active.length) {
              const activePoint = chart.controller.tooltip._active[0];
              const ctx = chart.ctx;
              const x = Math.abs(activePoint.tooltipPosition().x);
              const y = activePoint.tooltipPosition().y;
              const topY = chart.scales['y-axis-0'].top;
              const bottomY = chart.scales['y-axis-0'].bottom;
              const end = chart.canvas.width;
              const vertical = ctx.createLinearGradient(0,x+30,0,y+30);
              const horizontal = ctx.createLinearGradient(0,0,x+30,y+30);
              vertical.addColorStop(y/(bottomY),"rgba(0,0,0,0)");
              vertical.addColorStop(1,'#4effa1');
              horizontal.addColorStop(x/(end),"rgba(0,0,0,0)");
              horizontal.addColorStop(1,'#4effa1');
    
              ctx.save();
              ctx.beginPath();
              ctx.moveTo(x, topY);
              ctx.lineTo(x, bottomY);
              ctx.moveTo(0, y);
              ctx.lineTo(end, y);
              ctx.lineWidth = 1;
              ctx.strokeStyle = horizontal;
              ctx.stroke();
              ctx.restore();
            }
          }
        });
        
    }
    
    gradient = (canv,color) => { //draws graph gradient
        const ctx = canv.getContext("2d");
        const gradient= ctx.createLinearGradient(0,100,0,400);
        gradient.addColorStop(0,color);
        gradient.addColorStop(0.5,this.props.color2);
        gradient.addColorStop(1,"rgba(0,0,0,0)");
        return gradient;
    }
    data = canvas => {
        const data = this.state.data;
        if(data.datasets){
            let colors = this.props.color1;
            data.datasets.forEach((line,i) => {
                line.backgroundColor = this.gradient(canvas, colors[i]);
                line.hoverBackgroundColor = "#4effa1";
                line.pointHitRadius = 20;
                line.pointRadius = 0;
                
                
            })
        }
        

        return data;
    }

    render(){
        return (
            <div>
            <Line 
            height="400%"
            width="800%"
            options = {this.state.options}
            data = {this.data}
            />
            </div>
        )
    }
}
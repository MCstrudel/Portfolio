import React from 'react'

export default class Banner extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            content: ["Overview", "Total signups", "Last week", "Total investments", "Average investment","Total exits"],
            valuta: "NOK"
        }
    }
    render(){
        return(
         <div className="banner">
             <div><p><span>{this.state.content[0].toUpperCase()}</span><select></select></p></div>
             <div><p>{this.state.content[1]}</p>
              <h3 id="tertiary" className="extrabold">{this.props.overhead.total_signups}</h3></div>
             <div><p>{this.state.content[2]}</p>
              <h3 id="secondary" className="extrabold">{this.props.overhead.last_week}</h3></div>
             <div><p>{this.state.content[3]}</p>
              <h3 id="primary" className="extrabold">{this.props.overhead.total_investments}</h3></div>
             <div><p>{this.state.content[4]}</p>
             <span id="tertiary" style={{font:"Montserrat-Thin",float:"left"}}>{this.state.valuta}</span>
             <h3 id="tertiary" className="extrabold" style={{
                 float:"right"
             }}>{this.props.overhead.average_investment}</h3></div>
             <div><p>{this.state.content[5]}</p>
              <h3 id="secondary" className="extrabold">{this.props.overhead.total_exits}</h3></div>
         </div>
        )
    }
}
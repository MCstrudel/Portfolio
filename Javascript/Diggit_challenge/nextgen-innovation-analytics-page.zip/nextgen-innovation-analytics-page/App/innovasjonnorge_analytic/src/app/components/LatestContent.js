import React from 'react'

export default class LatestContent extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            meetings: this.props.meetings
        }
    }

    addMeeting = (list,n, d) => {
        return(
        <li><span>{n}</span><span>{d}</span></li>
        );
    }

    render(){
        
        return(
            <div className="meetings">
                <div className="latest_header">
                <p style={{position:"relative", left:"-20vmin",float:"top"}}>Latest Signup</p>
                <div style={{
                    display:"flex", 
                    flexDirection:"row", 
                    justifyContent: "space-between",
                    float: "bottom"}}>
                    <div >Name</div><div style={{whiteSpace:"pre"}}>Scheduled Meeting        </div></div>
              </div>
         <ul style={{
             width:"100%"
         }}>
             {
                this.state.meetings.map((m) =>
             <li><li style={{
                display:"flex", 
                flexDirection:"row", 
                justifyContent: "space-between",
                }}
             className="meeting" id={m.type}><span>{m.name}</span><span style={{whiteSpace:"pre"}}>{m.time}</span></li>
             <div className="line"></div></li>
                 )
             }
             
         </ul>
            </div>
         )
        
    }
}
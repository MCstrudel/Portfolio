import React from 'react'

export default class ChartMenu extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            content: ["Signups", "Investments", "Revenue", "Exits", "Trades"]
        }
    }
    render(){
        return(
         <menu className="chart_menu">
             <button>{this.state.content[0]}</button>
             <button>{this.state.content[1]}</button>
             <button>{this.state.content[2]}</button>
             <button>{this.state.content[3]}</button>
             <button>{this.state.content[4]}</button>
         </menu>
        )
    }
}
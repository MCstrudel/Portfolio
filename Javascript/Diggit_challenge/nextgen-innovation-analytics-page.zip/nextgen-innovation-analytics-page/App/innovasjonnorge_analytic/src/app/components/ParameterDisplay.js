import React from 'react'

export default class ParameterDisplay extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            parameter: this.props.parameter, 
            parameterOptions: this.props.parameterOptions,
            //value: NOT YET SUPPORTED
        }
    }
    render(){
        return(
         <div className="parameter_display">
            <span className="parameter" id="total">{"By "+this.state.parameter}</span>
            <select>
                {this.state.parameterOptions.map((o) =>
                <option>{o}</option>
             )}
            </select>
            <select>
                <option>Individuals</option>
                <option>Companies</option>
            </select>
                <span id="tertiary">102</span>
         </div>
        )
    }
}
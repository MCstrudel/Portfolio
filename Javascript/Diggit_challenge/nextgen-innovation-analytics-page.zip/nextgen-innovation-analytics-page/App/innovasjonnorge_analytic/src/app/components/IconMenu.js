import React from 'react'
/*import icMenu1 from "../assets/icons/funds.svg" 
import icMenu2 from "../assets/icons/Group_174.svg" 
import icMenu3 from "../assets/icons/history.svg"
import icMenu4 from "../assets/icons/locked-padlock.svg" 
import icMenu5 from "../assets/icons/Path_188.svg"
import icMenu6 from "../assets/icons/verification-window-button.svg"*/

export default class IconMenu extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            content: this.props.content
        }
    }
    render(){
        return(
         <menu className="chart_icons">
             <button><img src={this.state.content[0]} /></button>
             <button><img src={this.state.content[1]} /></button>
             <button><img src={this.state.content[2]} /></button>
             <button><img src={this.state.content[3]} /></button>
             <button><img src={this.state.content[4]} /></button>
             <button><img src={this.state.content[5]} /></button>
         </menu>
        )
    }
}
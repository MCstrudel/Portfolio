import React from 'react'
import {Doughnut} from 'react-chartjs-2'

export default class DoughnutGraph extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            data: {
                datasets: [{
                    label: "Total Signups",
                    labels: this.props.labels,
                    data: this.props.data,
                    backgroundColor: ["#1bfbe4","#ff56ee"],
                    borderWidth: 0,
                },]
            },
            options: {
                responsive: true,
                cutoutPercentage: 80,
                legend: {
                    display: false
                },
                showToolTips: false,
                tooltips: {
                    enabled: false
                }
            }
        }
    }
    

    render(){
        return (
            <div id="element"
            className="doughnut"
            >
                <div
                style={{
                    position: "relative",
                    left: "-0px"
                }}
                >
                <p style={{position: "absolute", top: "34%", left: "32%",fontSize: "200%",fontFamily: "Montserrat-Bold"}}>{
                    (this.props.data.reduce((a,b) => a+b))
                }</p>
                <Doughnut 
                height="250%"
                width="250%"
                options = {this.state.options}
                data = {this.state.data}
                />
                </div>
                <div 
                style={{
                    
                }}
                >
                    <div
                    style={{
                        position:"relative",
                        left:"20%",
                    }}
                    >
                     <p
                     style={{marginBottom:"50px"}}
                     >Total Signups</p>
                     <div style={{
                      borderRight:"4px solid var(--primary-color)",
                      display:"flex", 
                      flexDirection:"row", 
                      justifyContent: "space-between",
                      padding:"2px",
                      width:"200px",
                      whiteSpace: "pre",
                      marginTop:"20px"}}>
                      <span style={{fontSize:"var(--text-size-small)"}}>{this.props.labels[0]}</span> 
                      <span>{this.props.data[0]} </span></div>

                     <div style={{
                      borderRight:"4px solid var(--secondary-color)",
                      display:"flex", 
                      flexDirection:"row", 
                      justifyContent:"space-between",
                      padding:"2px",
                      width:"200px",
                      whiteSpace:"pre",
                      marginTop:"20px"
                      }}>
                     <span style={{fontSize:"var(--text-size-small)"}}>{this.props.labels[1]}</span> 
                     <span>{this.props.data[1]} </span></div>
                    </div>
                </div>
            </div>
        )
    }
}
import { createSlice } from '@reduxjs/toolkit';
import avatar from "../../assets/images/avatar.png";

export const dataSlice = createSlice({
  name: 'data',
  initialState: {
    value: { 
      //Filled with dummy example data. TODO: import and format actual data
      data: {
        individuals: [[0,9,3,6,2,5,6,10,11,10,8,5,9,7,0,10,10,10,1,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,2]],
        companies: [[9,5,6,5,2,2,6,3,9,1,4,4,3,5,3,10,10,10,1,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,0,10,10,10,10,10,10,11,10,10,5]],
        timestamps: ["","Jun'19","","Jul'19","","Aug'19","","Sep'19","","Oct'19","","Nov'19","","Dec'19",""]},
      overhead: {
        total_signups: 648,
        last_week: 12,
        total_investments: 102,
        average_investment: "345,565",
        total_exits: 23},
      parameters: { //TODO: needs to reference actual data parameters instead of hardcode
        gender: {
          name: "Gender",
          options: ["Female", "Male", "Other"],
          value: [102,(284-102),0] 
        }
      },
      meetings: [{ //Time of different formats should format to same length
        name: "David Hansen", 
        time: "02-03-2020 - 2PM       ", 
        type: "individual"
      },
      {
        name: "Shopify",
        time: "05-03-2020 - 10:30AM",
        type: "company"
      },
      {
        name: "Arvid, Realtree AB",
        time: "05-03-2020 - 3PM       ",
        type: "company" 
      }],
      profile: { //TODO: move to separate store for account page development
        name: "Elsa Andersen",
        imgsrc: avatar,
        type: "individual"
      }
    },
  },
  reducers: {
    signups: state => {
      // Signups
    },
    investments: state => {
      // Investments
    },
    revenue: state => {
      // Revenue
    },
    exits: state => {
      // Exits
    },
    trades: state => {
      // Trades
    },
  },
});
export const selectData = state => state.data.value;

export const {signups, investments, revenue, exits, trades} = dataSlice.actions;


export default dataSlice.reducer;
